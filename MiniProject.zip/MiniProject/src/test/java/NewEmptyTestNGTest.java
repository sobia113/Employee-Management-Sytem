/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/EmptyTestNGTest.java to edit this template
 */


import hello.miniproject.Login;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

/**
 *
 * @author Administrator
 */
public class NewEmptyTestNGTest {
     public static void main(String[] args) {
        org.testng.TestNG testSuite = new org.testng.TestNG();
        Class[] classes = new Class[] { NewEmptyTestNGTest.class };
        testSuite.setTestClasses(classes);
        testSuite.run();
    }
    

    private Login login;
   

    @BeforeClass
    public void setUp() {
        login = new Login();
        login.setVisible(false); 
    }

    @AfterClass
    public void tearDown() {
        login.dispose(); 
    }

    @Test

public void testValidLogin()  {
   
    String expectedMessage = "Login Successful";
    login.getUsernameField().setText("Admin");
    login.getPasswordField().setText("abc");
    login.getLoginButton().doClick();
    
String actualMessage=login.getMessage1();
        Assert.assertEquals(actualMessage, expectedMessage);

   
}

@Test
public void testEmptyFields() {
     
    String expectedMessage = "Fill all the fields"; 
    login.getUsernameField().setText("");
    login.getPasswordField().setText("");
    login.getLoginButton().doClick();
    String actualMessage=login.getMessage1();
        Assert.assertEquals(actualMessage, expectedMessage);

  
}

@Test
public void testInvalidPassword() {
    String expectedMessage = "Invalid Password"; 
    login.getUsernameField().setText("Admin");
    login.getPasswordField().setText("wrongPassword");
    login.getLoginButton().doClick();
   String actualMessage=login.getMessage1();
        Assert.assertEquals(actualMessage, expectedMessage);

    
}

@Test
public void testInvalidUsername() {
    String expectedMessage = "Invalid UserName"; 
    login.getUsernameField().setText("InvalidUser");
    login.getPasswordField().setText("abc");
    login.getLoginButton().doClick();
    String actualMessage=login.getMessage1();
        Assert.assertEquals(actualMessage, expectedMessage);

    
}

@Test
public void testInvalidUsernameAndPassword() {
    String expectedMessage = "Invalid UserName or Password"; 
    login.getUsernameField().setText("InvalidUser");
    login.getPasswordField().setText("WrongPass");
    login.getLoginButton().doClick();
    String actualMessage=login.getMessage1();
        Assert.assertEquals(actualMessage, expectedMessage);

    
}}

 